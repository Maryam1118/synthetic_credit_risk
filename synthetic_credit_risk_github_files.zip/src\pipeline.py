"""End-to-end training pipeline."""

from __future__ import annotations

import argparse
import logging

from src.evaluate_synthetic import evaluate_synthetic_data
from src.explainability import save_shap_plots
from src.preprocessing import preprocess_pipeline
from src.privacy_fairness import run_privacy_fairness_analysis
from src.train_ctgan import train_and_generate
from src.train_models import train_all_models

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def run_pipeline(ctgan_epochs: int = 300) -> None:
    """Run preprocessing, CTGAN, modeling, evaluation, privacy, fairness, and SHAP."""
    preprocess_pipeline()
    train_and_generate(epochs=ctgan_epochs)
    train_all_models()
    evaluate_synthetic_data()
    run_privacy_fairness_analysis()
    save_shap_plots()
    LOGGER.info("End-to-end pipeline complete.")


if __name__ == "__main__":
    setup_logging()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ctgan-epochs", type=int, default=300)
    args = parser.parse_args()
    run_pipeline(ctgan_epochs=args.ctgan_epochs)
