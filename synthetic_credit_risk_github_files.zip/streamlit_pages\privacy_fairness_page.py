"""Privacy and fairness metrics dashboard page."""

from __future__ import annotations

import json

import pandas as pd
import streamlit as st

from src.config import PRIVACY_FAIRNESS_PATH
from streamlit_pages.style import metric_card


def render() -> None:
    """Render privacy and fairness analysis."""
    st.header("Privacy & Fairness Metrics")
    if not PRIVACY_FAIRNESS_PATH.exists():
        st.info("Run `python -m src.privacy_fairness` to create privacy and fairness metrics.")
        return

    data = json.loads(PRIVACY_FAIRNESS_PATH.read_text(encoding="utf-8"))
    dcr = data.get("distance_to_closest_record", {})
    membership = data.get("membership_inference", {})
    fairness = data.get("fairness", {})

    c1, c2, c3 = st.columns(3)
    with c1:
        metric_card("Median DCR", f"{dcr.get('dcr_median', 0):.3f}")
    with c2:
        metric_card("Membership Risk", f"{membership.get('membership_risk_rate', 0):.2%}")
    with c3:
        metric_card("Equal Opportunity Diff", f"{fairness.get('equal_opportunity_difference', 0):.3f}")

    age_metrics = fairness.get("age_group_metrics", [])
    if age_metrics:
        st.dataframe(pd.DataFrame(age_metrics), use_container_width=True)
    st.json(data)
