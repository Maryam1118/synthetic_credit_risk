"""Synthetic data comparison dashboard page."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from src.config import NUMERIC_COLUMNS, TARGET_COLUMN
from streamlit_pages.style import metric_card


def render(real_df: pd.DataFrame, synthetic_df: pd.DataFrame | None, quality_df: pd.DataFrame | None) -> None:
    """Render synthetic fidelity charts and metrics."""
    st.header("Synthetic Data Comparison")
    if synthetic_df is None or synthetic_df.empty:
        st.info("Run `python -m src.train_ctgan` to generate synthetic records.")
        return

    c1, c2, c3 = st.columns(3)
    with c1:
        metric_card("Synthetic Rows", f"{len(synthetic_df):,}")
    with c2:
        metric_card("Synthetic Default Rate", f"{synthetic_df[TARGET_COLUMN].mean():.2%}")
    with c3:
        overlap = quality_df["distribution_overlap"].mean() if quality_df is not None else float("nan")
        metric_card("Avg Overlap", f"{overlap:.3f}" if pd.notna(overlap) else "N/A")

    feature = st.selectbox("Compare feature", NUMERIC_COLUMNS, index=1)
    plot_df = pd.concat(
        [
            real_df[[feature]].assign(source="Real"),
            synthetic_df[[feature]].assign(source="Synthetic"),
        ],
        ignore_index=True,
    )
    st.plotly_chart(
        px.histogram(plot_df, x=feature, color="source", barmode="overlay", opacity=0.62, title="Distribution Fidelity"),
        use_container_width=True,
    )

    left, right = st.columns(2)
    with left:
        st.plotly_chart(px.imshow(real_df[NUMERIC_COLUMNS].corr(), zmin=-1, zmax=1, color_continuous_scale="RdBu_r", title="Real Correlation"), use_container_width=True)
    with right:
        st.plotly_chart(px.imshow(synthetic_df[NUMERIC_COLUMNS].corr(), zmin=-1, zmax=1, color_continuous_scale="RdBu_r", title="Synthetic Correlation"), use_container_width=True)

    if quality_df is not None:
        st.dataframe(quality_df, use_container_width=True)
