"""Train a CTGAN model and generate synthetic minority-class credit records."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import pandas as pd
from sdv.metadata import SingleTableMetadata
from sdv.sampling import Condition
from sdv.single_table import CTGANSynthesizer

from src.config import (
    CATEGORICAL_COLUMNS,
    CLEAN_TRAIN_PATH,
    CTGAN_MODEL_PATH,
    MODEL_DIR,
    RANDOM_SEED,
    SYNTHETIC_DATA_PATH,
    TARGET_COLUMN,
)

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def build_metadata(train_df: pd.DataFrame) -> SingleTableMetadata:
    """Infer SDV metadata and mark engineered categorical columns."""
    metadata = SingleTableMetadata()
    metadata.detect_from_dataframe(train_df)
    for col in CATEGORICAL_COLUMNS + [TARGET_COLUMN]:
        metadata.update_column(column_name=col, sdtype="categorical")
    return metadata


def train_ctgan(
    train_path: Path = CLEAN_TRAIN_PATH,
    epochs: int = 300,
    batch_size: int = 500,
) -> CTGANSynthesizer:
    """Train and persist a CTGAN synthesizer on the preprocessed training set."""
    if not train_path.exists():
        raise FileNotFoundError(f"Clean training data not found at {train_path}. Run preprocessing first.")
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    train_df = pd.read_csv(train_path)
    metadata = build_metadata(train_df)
    synthesizer = CTGANSynthesizer(
        metadata=metadata,
        epochs=epochs,
        batch_size=batch_size,
        verbose=True,
        cuda=False,
    )
    synthesizer.fit(train_df)
    synthesizer.save(filepath=CTGAN_MODEL_PATH)
    LOGGER.info("Saved CTGAN model to %s", CTGAN_MODEL_PATH)
    return synthesizer


def generate_minority_samples(
    synthesizer: CTGANSynthesizer,
    train_df: pd.DataFrame,
    output_path: Path = SYNTHETIC_DATA_PATH,
    balance_strategy: str = "match_majority",
) -> pd.DataFrame:
    """Generate a balanced synthetic dataset using conditional class sampling."""
    class_counts = train_df[TARGET_COLUMN].value_counts()
    minority_class = int(class_counts.idxmin())
    majority_count = int(class_counts.max())
    minority_count = int(class_counts.min())
    if balance_strategy == "match_majority":
        rows_per_class = majority_count
    else:
        rows_per_class = minority_count

    conditions = [
        Condition(num_rows=rows_per_class, column_values={TARGET_COLUMN: class_value})
        for class_value in sorted(class_counts.index.astype(int).tolist())
    ]
    synthetic = synthesizer.sample_from_conditions(conditions=conditions)
    synthetic[TARGET_COLUMN] = synthetic[TARGET_COLUMN].astype(int)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    synthetic.to_csv(output_path, index=False)
    LOGGER.info(
        "Generated %s balanced synthetic records with minority class %s at %s",
        len(synthetic),
        minority_class,
        output_path,
    )
    return synthetic


def train_and_generate(train_path: Path = CLEAN_TRAIN_PATH, epochs: int = 300) -> pd.DataFrame:
    """Train CTGAN and generate a synthetic dataset."""
    train_df = pd.read_csv(train_path)
    synthesizer = train_ctgan(train_path=train_path, epochs=epochs)
    return generate_minority_samples(synthesizer, train_df)


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-path", type=Path, default=CLEAN_TRAIN_PATH)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--batch-size", type=int, default=500)
    return parser.parse_args()


if __name__ == "__main__":
    setup_logging()
    args = parse_args()
    train_df_arg = pd.read_csv(args.train_path)
    model = train_ctgan(args.train_path, epochs=args.epochs, batch_size=args.batch_size)
    generate_minority_samples(model, train_df_arg)
