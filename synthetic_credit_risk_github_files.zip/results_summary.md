# Results Summary

This run used the extracted Kaggle Give Me Some Credit training data from `data/raw/cs-training.csv`.

## Data

- Clean training rows: 119,512
- Clean test rows: 29,879
- Real default rate: 6.70%
- Balanced CTGAN synthetic rows: 223,010

## Best Model

The best held-out ROC-AUC came from `real/xgboost`.

| Training Data | Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|---:|
| real | xgboost | 0.9337 | 0.6111 | 0.0275 | 0.0526 | 0.8071 |
| real | logistic_regression | 0.7370 | 0.1661 | 0.7273 | 0.2704 | 0.7957 |
| real | random_forest | 0.7968 | 0.1911 | 0.6284 | 0.2930 | 0.7913 |

## Synthetic Fidelity

- Correlation similarity: 0.9378
- Example distribution overlap:
  - `RevolvingUtilizationOfUnsecuredLines`: 0.8307
  - `age`: 0.8234
  - `DebtRatio`: 0.7991
  - `MonthlyIncome`: 0.7797

The current saved CTGAN artifact was trained as a short artifact run. For final research results, rerun `python -m src.train_ctgan --epochs 300` and then rerun the evaluation/modeling scripts.
