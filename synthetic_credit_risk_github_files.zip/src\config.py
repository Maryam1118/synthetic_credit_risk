"""Project configuration constants."""

from __future__ import annotations

from pathlib import Path

RANDOM_SEED = 42
TARGET_COLUMN = "SeriousDlqin2yrs"

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
MODEL_DIR = PROJECT_ROOT / "models"
REPORT_DIR = PROJECT_ROOT / "reports"
FIGURE_DIR = REPORT_DIR / "figures"

RAW_DATA_PATH = RAW_DATA_DIR / "cs-training.csv"
CLEAN_TRAIN_PATH = PROCESSED_DATA_DIR / "train_clean.csv"
CLEAN_TEST_PATH = PROCESSED_DATA_DIR / "test_clean.csv"
SYNTHETIC_DATA_PATH = DATA_DIR / "synthetic_data.csv"
CTGAN_MODEL_PATH = MODEL_DIR / "ctgan.pkl"
BEST_MODEL_PATH = MODEL_DIR / "best_model.pkl"
PREPROCESSOR_PATH = MODEL_DIR / "preprocessor.joblib"
METRICS_PATH = REPORT_DIR / "model_metrics.csv"
QUALITY_REPORT_PATH = REPORT_DIR / "synthetic_quality_metrics.csv"
PRIVACY_FAIRNESS_PATH = REPORT_DIR / "privacy_fairness_metrics.json"

FEATURE_COLUMNS = [
    "RevolvingUtilizationOfUnsecuredLines",
    "age",
    "NumberOfTime30-59DaysPastDueNotWorse",
    "DebtRatio",
    "MonthlyIncome",
    "NumberOfOpenCreditLinesAndLoans",
    "NumberOfTimes90DaysLate",
    "NumberRealEstateLoansOrLines",
    "NumberOfTime60-89DaysPastDueNotWorse",
    "NumberOfDependents",
    "age_group",
    "income_band",
    "debt_level",
]

NUMERIC_COLUMNS = [
    "RevolvingUtilizationOfUnsecuredLines",
    "age",
    "NumberOfTime30-59DaysPastDueNotWorse",
    "DebtRatio",
    "MonthlyIncome",
    "NumberOfOpenCreditLinesAndLoans",
    "NumberOfTimes90DaysLate",
    "NumberRealEstateLoansOrLines",
    "NumberOfTime60-89DaysPastDueNotWorse",
    "NumberOfDependents",
]

CATEGORICAL_COLUMNS = ["age_group", "income_band", "debt_level"]
