"""Privacy risk and fairness analysis for synthetic data and credit models."""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import pairwise_distances

from src.config import (
    BEST_MODEL_PATH,
    CLEAN_TEST_PATH,
    CLEAN_TRAIN_PATH,
    FEATURE_COLUMNS,
    NUMERIC_COLUMNS,
    PRIVACY_FAIRNESS_PATH,
    REPORT_DIR,
    SYNTHETIC_DATA_PATH,
    TARGET_COLUMN,
)

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def sample_for_distance(df: pd.DataFrame, max_rows: int, random_state: int = 42) -> pd.DataFrame:
    """Return a reproducible sample for tractable pairwise distance metrics."""
    if len(df) <= max_rows:
        return df
    return df.sample(n=max_rows, random_state=random_state)


def distance_to_closest_record(
    real_df: pd.DataFrame,
    synthetic_df: pd.DataFrame,
    max_real_rows: int = 10_000,
    max_synthetic_rows: int = 10_000,
) -> dict[str, float]:
    """Calculate DCR summary statistics using numeric feature space."""
    real_df = sample_for_distance(real_df, max_real_rows)
    synthetic_df = sample_for_distance(synthetic_df, max_synthetic_rows)
    real_matrix = real_df[NUMERIC_COLUMNS].to_numpy(dtype=float)
    synth_matrix = synthetic_df[NUMERIC_COLUMNS].to_numpy(dtype=float)
    distances = pairwise_distances(synth_matrix, real_matrix, metric="euclidean")
    closest = distances.min(axis=1)
    return {
        "dcr_mean": float(np.mean(closest)),
        "dcr_median": float(np.median(closest)),
        "dcr_min": float(np.min(closest)),
        "dcr_p05": float(np.percentile(closest, 5)),
    }


def membership_inference_risk(
    real_df: pd.DataFrame,
    synthetic_df: pd.DataFrame,
    max_real_rows: int = 5_000,
    max_synthetic_rows: int = 10_000,
) -> dict[str, float]:
    """Approximate membership risk from close synthetic-real neighbor rates."""
    real_df = sample_for_distance(real_df, max_real_rows)
    synthetic_df = sample_for_distance(synthetic_df, max_synthetic_rows)
    real_matrix = real_df[NUMERIC_COLUMNS].to_numpy(dtype=float)
    synth_matrix = synthetic_df[NUMERIC_COLUMNS].to_numpy(dtype=float)
    closest = pairwise_distances(synth_matrix, real_matrix, metric="euclidean").min(axis=1)
    threshold = np.percentile(pairwise_distances(real_matrix[: min(len(real_matrix), 1000)], metric="euclidean"), 1)
    risk_rate = float(np.mean(closest <= threshold))
    return {"membership_risk_rate": risk_rate, "membership_distance_threshold": float(threshold)}


def demographic_parity(predictions: pd.Series, groups: pd.Series) -> float:
    """Return max-min positive prediction-rate difference across groups."""
    rates = pd.DataFrame({"pred": predictions, "group": groups}).groupby("group")["pred"].mean()
    return float(rates.max() - rates.min()) if len(rates) > 1 else 0.0


def equal_opportunity_difference(y_true: pd.Series, predictions: pd.Series, groups: pd.Series) -> float:
    """Return max-min true positive-rate difference across groups."""
    df = pd.DataFrame({"y": y_true, "pred": predictions, "group": groups})
    tprs = []
    for _, group_df in df.groupby("group"):
        positives = group_df[group_df["y"] == 1]
        if len(positives) > 0:
            tprs.append(float(positives["pred"].mean()))
    return float(max(tprs) - min(tprs)) if len(tprs) > 1 else 0.0


def fairness_by_age_group(model: object, test_df: pd.DataFrame) -> dict[str, object]:
    """Evaluate demographic parity and equal opportunity by engineered age group."""
    predictions = pd.Series(model.predict(test_df[FEATURE_COLUMNS]), index=test_df.index)
    groups = test_df["age_group"]
    group_table = []
    for group, group_df in test_df.assign(prediction=predictions).groupby("age_group"):
        positives = group_df[group_df[TARGET_COLUMN] == 1]
        group_table.append(
            {
                "age_group": str(group),
                "count": int(len(group_df)),
                "prediction_rate": float(group_df["prediction"].mean()),
                "true_positive_rate": float(positives["prediction"].mean()) if len(positives) else 0.0,
                "actual_default_rate": float(group_df[TARGET_COLUMN].mean()),
            }
        )
    return {
        "demographic_parity_difference": demographic_parity(predictions, groups),
        "equal_opportunity_difference": equal_opportunity_difference(test_df[TARGET_COLUMN], predictions, groups),
        "age_group_metrics": group_table,
    }


def run_privacy_fairness_analysis(
    real_path: Path = CLEAN_TRAIN_PATH,
    synthetic_path: Path = SYNTHETIC_DATA_PATH,
    test_path: Path = CLEAN_TEST_PATH,
    model_path: Path = BEST_MODEL_PATH,
) -> dict[str, object]:
    """Run privacy and fairness analysis and persist JSON metrics."""
    for path in [real_path, synthetic_path, test_path, model_path]:
        if not path.exists():
            raise FileNotFoundError(f"Required artifact missing: {path}")
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    real_df = pd.read_csv(real_path)
    synthetic_df = pd.read_csv(synthetic_path)
    test_df = pd.read_csv(test_path)
    model = joblib.load(model_path)
    results: dict[str, object] = {
        "distance_to_closest_record": distance_to_closest_record(real_df, synthetic_df),
        "membership_inference": membership_inference_risk(real_df, synthetic_df),
        "fairness": fairness_by_age_group(model, test_df),
    }
    PRIVACY_FAIRNESS_PATH.write_text(json.dumps(results, indent=2), encoding="utf-8")
    LOGGER.info("Saved privacy and fairness metrics to %s", PRIVACY_FAIRNESS_PATH)
    return results


if __name__ == "__main__":
    setup_logging()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    run_privacy_fairness_analysis()
