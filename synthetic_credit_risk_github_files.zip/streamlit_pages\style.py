"""Shared Streamlit styling helpers."""

from __future__ import annotations

import streamlit as st


def apply_dark_theme() -> None:
    """Apply a dark fintech research dashboard theme."""
    st.markdown(
        """
        <style>
        :root {
            --bg: #050711;
            --panel: #111426;
            --panel-2: #18122c;
            --muted: #a8a9c9;
            --text: #f6f2ff;
            --accent: #a855f7;
            --accent-2: #38bdf8;
            --accent-3: #fb7185;
            --line: rgba(209, 190, 255, .16);
        }
        .stApp {
            background: radial-gradient(circle at top left, rgba(168,85,247,.16), transparent 30%),
                        radial-gradient(circle at bottom right, rgba(56,189,248,.10), transparent 26%),
                        linear-gradient(135deg, #050711 0%, #0b1020 52%, #160b2b 100%);
            color: var(--text);
        }
        header[data-testid="stHeader"] {
            background: transparent;
            height: 0;
        }
        header[data-testid="stHeader"] > div {
            display: none;
        }
        footer {
            display: none;
        }
        #MainMenu {
            display: none;
        }
        [data-testid="stSidebar"] {
            background: rgba(5,7,17,.96);
            border-right: 1px solid var(--line);
        }
        [data-testid="stSidebarCollapsedControl"] {
            color: #f6f2ff;
            background: rgba(17,20,38,.88);
            border: 1px solid rgba(209,190,255,.18);
            border-radius: 6px;
            top: 10px;
            left: 10px;
        }
        .block-container {
            padding-top: .55rem;
            padding-bottom: 1.5rem;
            max-width: 1440px;
        }
        .metric-card {
            background: linear-gradient(145deg, rgba(22,25,49,.96), rgba(18,13,39,.88));
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 14px 16px;
            min-height: 92px;
            box-shadow: 0 12px 32px rgba(0,0,0,.24);
        }
        .metric-card .label {
            color: var(--muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .03em;
        }
        .metric-card .value {
            color: var(--text);
            font-size: 26px;
            font-weight: 750;
            margin-top: 6px;
        }
        .section-panel {
            background: linear-gradient(180deg, rgba(19,23,45,.96), rgba(14,17,34,.94));
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 14px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.04), 0 18px 36px rgba(0,0,0,.28);
        }
        .dashboard-title {
            text-align: center;
            font-size: 21px;
            font-weight: 900;
            font-style: italic;
            text-decoration: underline;
            letter-spacing: 0;
            color: #ffffff;
            margin: 0 0 10px;
        }
        .panel-title {
            color: #ffffff;
            font-weight: 800;
            font-size: 14px;
            text-align: center;
            margin-bottom: 8px;
        }
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 8px;
        }
        .filter-pill {
            background: rgba(43,28,72,.92);
            border: 1px solid rgba(209,190,255,.18);
            border-radius: 4px;
            padding: 10px 8px;
            color: #f6f2ff;
            text-align: center;
            font-size: 12px;
            font-weight: 700;
        }
        .risk-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }
        .risk-table th, .risk-table td {
            border-bottom: 1px solid rgba(209,190,255,.14);
            padding: 7px 4px;
            color: #f6f2ff;
        }
        .risk-table th {
            color: #d9c8ff;
            font-size: 11px;
            text-transform: uppercase;
        }
        .mini-kpi {
            background: linear-gradient(145deg, rgba(22,25,49,.98), rgba(13,17,34,.92));
            border: 1px solid rgba(209,190,255,.16);
            border-radius: 6px;
            padding: 13px 10px;
            min-height: 82px;
            text-align: center;
        }
        .mini-kpi .value {
            font-size: 23px;
            font-weight: 850;
            color: #f6f2ff;
        }
        .mini-kpi .label {
            color: #a8a9c9;
            font-size: 12px;
            margin-top: 5px;
        }
        .stPlotlyChart {
            background: linear-gradient(180deg, rgba(19,23,45,.96), rgba(14,17,34,.94));
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 6px;
        }
        .modebar {
            display: none !important;
        }
        .risk-high { color: #fb7185; font-weight: 800; }
        .risk-low { color: #38bdf8; font-weight: 800; }
        h1, h2, h3 { letter-spacing: 0; }
        div[data-testid="stMetric"] {
            background: linear-gradient(145deg, rgba(22,25,49,.96), rgba(18,13,39,.88));
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 12px;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def metric_card(label: str, value: str, caption: str = "") -> None:
    """Render a compact dashboard metric card."""
    st.markdown(
        f"""
        <div class="metric-card">
          <div class="label">{label}</div>
          <div class="value">{value}</div>
          <div style="color:#9fb0c0;font-size:13px;margin-top:4px;">{caption}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def mini_kpi(label: str, value: str) -> None:
    """Render a compact Power BI-style KPI tile."""
    st.markdown(
        f"""
        <div class="mini-kpi">
          <div class="value">{value}</div>
          <div class="label">{label}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def panel_title(title: str) -> None:
    """Render a consistent dashboard panel title."""
    st.markdown(f"<div class='panel-title'>{title}</div>", unsafe_allow_html=True)
