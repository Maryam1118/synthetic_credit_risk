"""Data analysis dashboard page."""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from src.config import NUMERIC_COLUMNS, TARGET_COLUMN
from streamlit_pages.style import metric_card


def render(df: pd.DataFrame) -> None:
    """Render exploratory data analysis."""
    st.header("Data Analysis")
    c1, c2, c3 = st.columns(3)
    with c1:
        metric_card("Rows", f"{len(df):,}")
    with c2:
        metric_card("Default Rate", f"{df[TARGET_COLUMN].mean():.2%}")
    with c3:
        metric_card("Features", f"{len(df.columns) - 1}")

    left, right = st.columns([1, 1])
    with left:
        fig = px.histogram(df, x=TARGET_COLUMN, color=TARGET_COLUMN, title="Class Distribution")
        st.plotly_chart(fig, use_container_width=True)
    with right:
        feature = st.selectbox("Numeric feature", NUMERIC_COLUMNS, index=0)
        fig = px.histogram(df, x=feature, color=TARGET_COLUMN, marginal="box", title=f"{feature} by Target")
        st.plotly_chart(fig, use_container_width=True)

    corr = df[NUMERIC_COLUMNS].corr()
    fig = px.imshow(corr, color_continuous_scale="RdBu_r", zmin=-1, zmax=1, title="Real Data Correlation")
    st.plotly_chart(fig, use_container_width=True)
