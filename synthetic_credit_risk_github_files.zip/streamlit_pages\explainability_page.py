"""Explainability dashboard page."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from src.config import FIGURE_DIR


def render() -> None:
    """Render saved SHAP artifacts."""
    st.header("Explainability")
    summary = FIGURE_DIR / "shap_summary.png"
    importance = FIGURE_DIR / "shap_feature_importance.png"
    if summary.exists():
        st.image(str(summary), caption="SHAP summary plot", use_container_width=True)
    if importance.exists():
        st.image(str(importance), caption="Global SHAP feature importance", use_container_width=True)
    if not summary.exists() and not importance.exists():
        st.info("Run `python -m src.explainability` after model training to generate SHAP plots.")
