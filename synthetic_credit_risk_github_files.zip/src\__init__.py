"""Synthetic financial data generation and credit risk assessment package."""
