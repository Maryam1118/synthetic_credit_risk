"""Preprocess the Give Me Some Credit dataset for modeling and CTGAN."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Iterable

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from src.config import (
    CLEAN_TEST_PATH,
    CLEAN_TRAIN_PATH,
    FEATURE_COLUMNS,
    NUMERIC_COLUMNS,
    PREPROCESSOR_PATH,
    PROCESSED_DATA_DIR,
    RANDOM_SEED,
    RAW_DATA_PATH,
    TARGET_COLUMN,
)

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def load_credit_data(path: Path = RAW_DATA_PATH) -> pd.DataFrame:
    """Load the Kaggle training CSV and remove the optional unnamed index column."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Download Kaggle Give Me Some Credit and place "
            "cs-training.csv in data/raw/."
        )
    df = pd.read_csv(path)
    unnamed = [col for col in df.columns if col.lower().startswith("unnamed")]
    if unnamed:
        df = df.drop(columns=unnamed)
    if TARGET_COLUMN not in df.columns:
        raise ValueError(f"Expected target column '{TARGET_COLUMN}' in {path}.")
    return df


def engineer_categorical_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create interpretable categorical risk bands used for CTGAN conditioning and fairness."""
    result = df.copy()
    result["age_group"] = pd.cut(
        result["age"],
        bins=[0, 30, 45, 60, 75, np.inf],
        labels=["under_30", "30_44", "45_59", "60_74", "75_plus"],
        right=False,
    ).astype("object")
    result["income_band"] = pd.cut(
        result["MonthlyIncome"],
        bins=[-np.inf, 2500, 5000, 8500, 14000, np.inf],
        labels=["very_low", "low", "middle", "upper_middle", "high"],
    ).astype("object")
    result["debt_level"] = pd.cut(
        result["DebtRatio"],
        bins=[-np.inf, 0.2, 0.5, 1.0, np.inf],
        labels=["low", "moderate", "high", "severe"],
    ).astype("object")
    return result


def cap_outliers_iqr(df: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    """Winsorize numeric columns using the IQR rule."""
    result = df.copy()
    for col in columns:
        q1 = result[col].quantile(0.25)
        q3 = result[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        result[col] = result[col].clip(lower=lower, upper=upper)
    return result


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Handle missing values, duplicates, outliers, and engineered features."""
    result = df.copy()
    result = result.drop_duplicates()

    for col in NUMERIC_COLUMNS:
        if col not in result.columns:
            raise ValueError(f"Required column '{col}' is missing.")
        median = result[col].median()
        result[col] = result[col].fillna(median)

    result = cap_outliers_iqr(result, NUMERIC_COLUMNS)
    result = engineer_categorical_features(result)
    result[TARGET_COLUMN] = result[TARGET_COLUMN].astype(int)
    return result[FEATURE_COLUMNS + [TARGET_COLUMN]]


def split_and_scale(
    df: pd.DataFrame,
    test_size: float = 0.2,
    random_state: int = RANDOM_SEED,
) -> tuple[pd.DataFrame, pd.DataFrame, StandardScaler]:
    """Create stratified train/test split and normalize numeric features."""
    train_df, test_df = train_test_split(
        df,
        test_size=test_size,
        stratify=df[TARGET_COLUMN],
        random_state=random_state,
    )
    scaler = StandardScaler()
    train_df = train_df.copy()
    test_df = test_df.copy()
    train_df[NUMERIC_COLUMNS] = scaler.fit_transform(train_df[NUMERIC_COLUMNS])
    test_df[NUMERIC_COLUMNS] = scaler.transform(test_df[NUMERIC_COLUMNS])
    return train_df, test_df, scaler


def analyze_class_imbalance(df: pd.DataFrame) -> pd.DataFrame:
    """Return target class counts and percentages."""
    counts = df[TARGET_COLUMN].value_counts().sort_index()
    return pd.DataFrame({"count": counts, "percentage": counts / counts.sum()})


def preprocess_pipeline(input_path: Path = RAW_DATA_PATH) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run the full preprocessing pipeline and save processed artifacts."""
    PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    PREPROCESSOR_PATH.parent.mkdir(parents=True, exist_ok=True)

    raw_df = load_credit_data(input_path)
    LOGGER.info("Loaded raw data with shape %s", raw_df.shape)
    cleaned_df = clean_dataframe(raw_df)
    LOGGER.info("Class balance:\n%s", analyze_class_imbalance(cleaned_df))
    train_df, test_df, scaler = split_and_scale(cleaned_df)

    train_df.to_csv(CLEAN_TRAIN_PATH, index=False)
    test_df.to_csv(CLEAN_TEST_PATH, index=False)
    joblib.dump({"scaler": scaler, "numeric_columns": NUMERIC_COLUMNS}, PREPROCESSOR_PATH)
    LOGGER.info("Saved train data to %s and test data to %s", CLEAN_TRAIN_PATH, CLEAN_TEST_PATH)
    return train_df, test_df


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=RAW_DATA_PATH, help="Path to cs-training.csv")
    return parser.parse_args()


if __name__ == "__main__":
    setup_logging()
    args = parse_args()
    preprocess_pipeline(args.input)
