"""Evaluate statistical fidelity of synthetic credit data."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.stats import ks_2samp, wasserstein_distance

from src.config import (
    CLEAN_TRAIN_PATH,
    FIGURE_DIR,
    NUMERIC_COLUMNS,
    QUALITY_REPORT_PATH,
    REPORT_DIR,
    SYNTHETIC_DATA_PATH,
)

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def distribution_overlap(real: pd.Series, synthetic: pd.Series, bins: int = 50) -> float:
    """Estimate histogram intersection between two one-dimensional distributions."""
    combined = pd.concat([real, synthetic]).dropna()
    hist_range = (combined.min(), combined.max())
    real_hist, bin_edges = np.histogram(real.dropna(), bins=bins, range=hist_range, density=True)
    synth_hist, _ = np.histogram(synthetic.dropna(), bins=bin_edges, density=True)
    widths = np.diff(bin_edges)
    return float(np.sum(np.minimum(real_hist, synth_hist) * widths))


def correlation_similarity(real_df: pd.DataFrame, synthetic_df: pd.DataFrame) -> float:
    """Compute similarity between numeric correlation matrices."""
    real_corr = real_df[NUMERIC_COLUMNS].corr().fillna(0)
    synth_corr = synthetic_df[NUMERIC_COLUMNS].corr().fillna(0)
    distance = np.linalg.norm(real_corr.values - synth_corr.values, ord="fro")
    max_distance = np.linalg.norm(np.ones_like(real_corr.values) * 2, ord="fro")
    return float(1 - distance / max_distance)


def compute_quality_metrics(real_df: pd.DataFrame, synthetic_df: pd.DataFrame) -> pd.DataFrame:
    """Calculate KS, Wasserstein, and distribution-overlap metrics per numeric feature."""
    records = []
    for col in NUMERIC_COLUMNS:
        real = real_df[col].dropna()
        synth = synthetic_df[col].dropna()
        ks = ks_2samp(real, synth)
        records.append(
            {
                "feature": col,
                "ks_statistic": ks.statistic,
                "ks_pvalue": ks.pvalue,
                "wasserstein_distance": wasserstein_distance(real, synth),
                "distribution_overlap": distribution_overlap(real, synth),
            }
        )
    metrics = pd.DataFrame(records)
    metrics["correlation_similarity"] = correlation_similarity(real_df, synthetic_df)
    return metrics


def save_visualizations(real_df: pd.DataFrame, synthetic_df: pd.DataFrame) -> None:
    """Save histograms, KDE plots, and correlation heatmaps."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="darkgrid")
    for col in NUMERIC_COLUMNS:
        plt.figure(figsize=(8, 5))
        sns.histplot(real_df[col], color="#2dd4bf", label="Real", stat="density", alpha=0.45)
        sns.histplot(synthetic_df[col], color="#f97316", label="Synthetic", stat="density", alpha=0.45)
        plt.legend()
        plt.title(f"Distribution comparison: {col}")
        plt.tight_layout()
        plt.savefig(FIGURE_DIR / f"hist_{col}.png", dpi=160)
        plt.close()

        plt.figure(figsize=(8, 5))
        if real_df[col].nunique(dropna=True) > 1 and synthetic_df[col].nunique(dropna=True) > 1:
            sns.kdeplot(real_df[col], color="#2dd4bf", label="Real", fill=True, alpha=0.2)
            sns.kdeplot(synthetic_df[col], color="#f97316", label="Synthetic", fill=True, alpha=0.2)
            plt.legend()
        else:
            sns.histplot(real_df[col], color="#2dd4bf", label="Real", stat="density", alpha=0.45)
            sns.histplot(synthetic_df[col], color="#f97316", label="Synthetic", stat="density", alpha=0.45)
            plt.legend()
        plt.title(f"KDE comparison: {col}")
        plt.tight_layout()
        plt.savefig(FIGURE_DIR / f"kde_{col}.png", dpi=160)
        plt.close()

    for name, df in {"real": real_df, "synthetic": synthetic_df}.items():
        plt.figure(figsize=(10, 8))
        sns.heatmap(df[NUMERIC_COLUMNS].corr(), cmap="vlag", center=0, square=True)
        plt.title(f"{name.title()} correlation heatmap")
        plt.tight_layout()
        plt.savefig(FIGURE_DIR / f"corr_{name}.png", dpi=160)
        plt.close()


def evaluate_synthetic_data(
    real_path: Path = CLEAN_TRAIN_PATH,
    synthetic_path: Path = SYNTHETIC_DATA_PATH,
) -> pd.DataFrame:
    """Run synthetic quality evaluation and save reports."""
    if not real_path.exists() or not synthetic_path.exists():
        raise FileNotFoundError("Real and synthetic CSV files are required for evaluation.")
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    real_df = pd.read_csv(real_path)
    synthetic_df = pd.read_csv(synthetic_path)
    metrics = compute_quality_metrics(real_df, synthetic_df)
    metrics.to_csv(QUALITY_REPORT_PATH, index=False)
    save_visualizations(real_df, synthetic_df)
    LOGGER.info("Saved quality metrics to %s", QUALITY_REPORT_PATH)
    return metrics


if __name__ == "__main__":
    setup_logging()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    evaluate_synthetic_data()
