"""Credit risk prediction dashboard page."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from src.config import CATEGORICAL_COLUMNS, FEATURE_COLUMNS, NUMERIC_COLUMNS


def input_record(default_df: pd.DataFrame) -> pd.DataFrame:
    """Collect one credit-risk record from Streamlit controls."""
    cols = st.columns(2)
    values: dict[str, object] = {}
    for idx, col in enumerate(NUMERIC_COLUMNS):
        source = default_df[col] if col in default_df else pd.Series([0.0])
        with cols[idx % 2]:
            values[col] = st.number_input(col, value=float(source.median()), step=0.1)

    values["age_group"] = st.selectbox("age_group", ["under_30", "30_44", "45_59", "60_74", "75_plus"], index=2)
    values["income_band"] = st.selectbox("income_band", ["very_low", "low", "middle", "upper_middle", "high"], index=2)
    values["debt_level"] = st.selectbox("debt_level", ["low", "moderate", "high", "severe"], index=1)
    return pd.DataFrame([values])[FEATURE_COLUMNS]


def render(model: object | None, reference_df: pd.DataFrame) -> None:
    """Render risk scoring workflow."""
    st.header("Credit Risk Prediction")
    if model is None:
        st.info("Train models first with `python -m src.train_models`.")
        return

    uploaded = st.file_uploader("Upload CSV for batch scoring", type=["csv"])
    if uploaded is not None:
        batch = pd.read_csv(uploaded)
        missing = [col for col in FEATURE_COLUMNS if col not in batch.columns]
        if missing:
            st.error(f"Missing required columns: {missing}")
        else:
            scored = batch.copy()
            scored["default_probability"] = model.predict_proba(batch[FEATURE_COLUMNS])[:, 1]
            scored["risk_prediction"] = model.predict(batch[FEATURE_COLUMNS])
            st.dataframe(scored, use_container_width=True)
            st.download_button("Download scored CSV", scored.to_csv(index=False), "credit_risk_scores.csv")
        return

    st.subheader("Single Applicant Scoring")
    record = input_record(reference_df)
    if st.button("Predict Default Risk", type="primary"):
        probability = float(model.predict_proba(record)[0, 1])
        prediction = int(model.predict(record)[0])
        label = "High risk" if prediction else "Lower risk"
        css = "risk-high" if prediction else "risk-low"
        st.markdown(f"<h2 class='{css}'>{label}: {probability:.2%}</h2>", unsafe_allow_html=True)
        st.dataframe(record, use_container_width=True)
