"""Tests for synthetic evaluation metrics."""

from __future__ import annotations

import pandas as pd

from src.evaluate_synthetic import distribution_overlap


def test_distribution_overlap_is_bounded() -> None:
    """Histogram overlap should stay within the unit interval for simple inputs."""
    real = pd.Series([0, 1, 2, 3, 4, 5])
    synth = pd.Series([0, 1, 2, 3, 4, 5])
    overlap = distribution_overlap(real, synth, bins=3)
    assert 0.0 <= overlap <= 1.05
