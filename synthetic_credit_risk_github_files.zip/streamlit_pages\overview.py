"""Project overview dashboard page."""

from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st

from src.config import TARGET_COLUMN
from streamlit_pages.style import mini_kpi, panel_title


PURPLE = "#a855f7"
PINK = "#d946ef"
LAVENDER = "#c084fc"
BLUE = "#38bdf8"
RED = "#fb7185"
PANEL_BG = "rgba(0,0,0,0)"


def chart_layout(fig: go.Figure, height: int = 230) -> go.Figure:
    """Apply dashboard chart styling."""
    fig.update_layout(
        height=height,
        margin=dict(l=12, r=12, t=14, b=20),
        paper_bgcolor=PANEL_BG,
        plot_bgcolor=PANEL_BG,
        font=dict(color="#f6f2ff", size=11),
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="center", x=0.5, font=dict(size=9)),
        xaxis=dict(gridcolor="rgba(209,190,255,.12)", zerolinecolor="rgba(209,190,255,.16)"),
        yaxis=dict(gridcolor="rgba(209,190,255,.12)", zerolinecolor="rgba(209,190,255,.16)"),
    )
    return fig


def safe_pct(value: float) -> str:
    """Format percentage values."""
    return f"{value:.2%}"


def risk_score(default_rate: float, auc: float | None) -> int:
    """Create a compact synthetic risk score for dashboard display."""
    auc_component = 0 if auc is None else int(max(0, min(40, (1 - auc) * 100)))
    return int(max(0, min(100, default_rate * 100 + auc_component)))


def risk_table_html(real_df: pd.DataFrame) -> str:
    """Create a small risk category table."""
    rows = []
    for group, group_df in real_df.groupby("debt_level", observed=True):
        rows.append((str(group).upper(), group_df[TARGET_COLUMN].mean()))
    rows = sorted(rows, key=lambda item: item[1], reverse=True)
    body = "".join(f"<tr><td>{name}</td><td>{rate:.0%}</td></tr>" for name, rate in rows[:5])
    return f"""
    <div class="section-panel">
      <div class="panel-title">Risky Debt Levels</div>
      <table class="risk-table">
        <thead><tr><th>Debt Level</th><th>Default Rate %</th></tr></thead>
        <tbody>{body}</tbody>
      </table>
    </div>
    """


def filters_html(real_df: pd.DataFrame) -> str:
    """Render non-interactive dashboard filter tiles."""
    labels = []
    labels.extend([str(x).upper() for x in real_df["debt_level"].dropna().unique()[:4]])
    labels.extend([str(x).upper() for x in real_df["income_band"].dropna().unique()[:5]])
    labels = labels[:9]
    pills = "".join(f"<div class='filter-pill'>{label}</div>" for label in labels)
    return f"<div class='section-panel'><div class='panel-title'>Risk Segments</div><div class='filter-grid'>{pills}</div></div>"


def render(real_df: pd.DataFrame, synthetic_df: pd.DataFrame | None, metrics_df: pd.DataFrame | None) -> None:
    """Render project overview."""
    st.markdown("<div class='dashboard-title'>CREDIT RISK DASHBOARD</div>", unsafe_allow_html=True)

    best_auc: float | None = None
    if metrics_df is not None and not metrics_df.empty and "roc_auc" in metrics_df:
        best_auc = float(metrics_df["roc_auc"].max())

    total_real = len(real_df)
    good_rate = 1 - real_df[TARGET_COLUMN].mean()
    default_rate = real_df[TARGET_COLUMN].mean()
    synthetic_count = 0 if synthetic_df is None else len(synthetic_df)
    predicted_defaults = default_rate if metrics_df is None or metrics_df.empty else float(metrics_df.iloc[0]["recall"]) * default_rate

    left, center, right = st.columns([1.05, 2.2, 1.2], gap="small")

    with left:
        st.markdown(risk_table_html(real_df), unsafe_allow_html=True)

        panel_title("Defaults by Debt Level")
        debt = (
            real_df.groupby("debt_level", observed=True)[TARGET_COLUMN]
            .agg(default_rate="mean", records="size")
            .reset_index()
            .sort_values("default_rate", ascending=False)
        )
        fig = go.Figure()
        fig.add_bar(x=debt["debt_level"], y=debt["records"], marker_color=PURPLE, name="Applicants")
        fig.add_scatter(
            x=debt["debt_level"],
            y=debt["default_rate"],
            mode="lines+markers",
            marker=dict(color=LAVENDER),
            line=dict(color=LAVENDER, width=3),
            name="Default Rate",
            yaxis="y2",
        )
        fig.update_layout(yaxis2=dict(overlaying="y", side="right", tickformat=".0%"))
        st.plotly_chart(chart_layout(fig, 218), use_container_width=True, config={"displayModeBar": False})

    with center:
        panel_title("All Applicants by Age Group")
        age_group = real_df.groupby("age_group", observed=True).size().reset_index(name="records")
        fig = px.pie(
            age_group,
            values="records",
            names="age_group",
            hole=0.55,
            color_discrete_sequence=[PURPLE, PINK, LAVENDER, BLUE, RED],
        )
        fig.update_traces(textposition="outside", textinfo="label+percent", marker=dict(line=dict(color="#111426", width=2)))
        st.plotly_chart(chart_layout(fig, 250), use_container_width=True, config={"displayModeBar": False})

        lower_left, lower_right = st.columns(2, gap="small")
        with lower_left:
            panel_title("Defaults by Income Band")
            income = (
                real_df.groupby("income_band", observed=True)[TARGET_COLUMN]
                .agg(default_rate="mean", records="size")
                .reset_index()
            )
            fig = go.Figure()
            fig.add_bar(x=income["income_band"], y=income["records"], marker_color=PURPLE, name="Applicants")
            fig.add_scatter(
                x=income["income_band"],
                y=income["default_rate"],
                mode="lines+markers",
                line=dict(color=LAVENDER, width=3),
                name="Default Rate",
                yaxis="y2",
            )
            fig.update_layout(yaxis2=dict(overlaying="y", side="right", tickformat=".0%"))
            st.plotly_chart(chart_layout(fig, 220), use_container_width=True, config={"displayModeBar": False})

        with lower_right:
            panel_title("Risk Score")
            score = risk_score(default_rate, best_auc)
            fig = go.Figure(
                go.Indicator(
                    mode="gauge+number",
                    value=score,
                    number={"font": {"color": "#f6f2ff", "size": 28}},
                    gauge={
                        "axis": {"range": [0, 100], "tickcolor": "#a8a9c9"},
                        "bar": {"color": PURPLE},
                        "bgcolor": "rgba(255,255,255,.06)",
                        "borderwidth": 0,
                        "steps": [
                            {"range": [0, 35], "color": "rgba(56,189,248,.18)"},
                            {"range": [35, 70], "color": "rgba(168,85,247,.20)"},
                            {"range": [70, 100], "color": "rgba(251,113,133,.20)"},
                        ],
                    },
                )
            )
            st.plotly_chart(chart_layout(fig, 220), use_container_width=True, config={"displayModeBar": False})

    with right:
        top1, top2 = st.columns(2, gap="small")
        with top1:
            mini_kpi("Good Loans %", safe_pct(good_rate))
        with top2:
            mini_kpi("Total Records", f"{total_real/1000:.1f}K")
        mid1, mid2 = st.columns(2, gap="small")
        with mid1:
            mini_kpi("Default Rate %", safe_pct(default_rate))
        with mid2:
            mini_kpi("Predicted Defaults %", safe_pct(predicted_defaults))
        mini_kpi("Synthetic Records", f"{synthetic_count/1000:.1f}K")
        mini_kpi("Best ROC-AUC", "N/A" if best_auc is None else f"{best_auc:.3f}")

    bottom_left, bottom_mid, bottom_right = st.columns([1.4, 1.0, 1.2], gap="small")
    with bottom_left:
        st.markdown(filters_html(real_df), unsafe_allow_html=True)
    with bottom_mid:
        panel_title("Model Leaderboard")
        if metrics_df is not None and not metrics_df.empty:
            display = metrics_df[["training_data", "model", "roc_auc", "recall"]].head(5).copy()
            display["roc_auc"] = display["roc_auc"].map(lambda x: f"{x:.3f}")
            display["recall"] = display["recall"].map(lambda x: f"{x:.3f}")
            st.dataframe(display, use_container_width=True, hide_index=True)
    with bottom_right:
        panel_title("Age Group Default Rate")
        age_default = real_df.groupby("age_group", observed=True)[TARGET_COLUMN].mean().reset_index()
        fig = px.bar(age_default, x="age_group", y=TARGET_COLUMN, color=TARGET_COLUMN, color_continuous_scale=["#38bdf8", "#a855f7", "#fb7185"])
        fig.update_layout(showlegend=False, yaxis_tickformat=".0%")
        st.plotly_chart(chart_layout(fig, 190), use_container_width=True, config={"displayModeBar": False})
