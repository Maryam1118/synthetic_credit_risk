"""Tests for preprocessing utilities."""

from __future__ import annotations

import pandas as pd

from src.config import FEATURE_COLUMNS, TARGET_COLUMN
from src.preprocessing import clean_dataframe


def test_clean_dataframe_adds_engineered_features() -> None:
    """The cleaner should impute, deduplicate, and return the modeling schema."""
    df = pd.DataFrame(
        {
            TARGET_COLUMN: [1, 0, 0],
            "RevolvingUtilizationOfUnsecuredLines": [0.8, 0.1, 0.1],
            "age": [45, 61, 61],
            "NumberOfTime30-59DaysPastDueNotWorse": [2, 0, 0],
            "DebtRatio": [0.8, 0.2, 0.2],
            "MonthlyIncome": [9000, None, None],
            "NumberOfOpenCreditLinesAndLoans": [13, 4, 4],
            "NumberOfTimes90DaysLate": [0, 0, 0],
            "NumberRealEstateLoansOrLines": [2, 1, 1],
            "NumberOfTime60-89DaysPastDueNotWorse": [0, 0, 0],
            "NumberOfDependents": [2, None, None],
        }
    )
    cleaned = clean_dataframe(df)
    assert list(cleaned.columns) == FEATURE_COLUMNS + [TARGET_COLUMN]
    assert cleaned.isna().sum().sum() == 0
    assert {"age_group", "income_band", "debt_level"}.issubset(cleaned.columns)
