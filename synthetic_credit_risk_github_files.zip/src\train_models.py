"""Train credit risk models on real, synthetic, and hybrid datasets."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBClassifier

from src.config import (
    BEST_MODEL_PATH,
    CATEGORICAL_COLUMNS,
    CLEAN_TEST_PATH,
    CLEAN_TRAIN_PATH,
    FEATURE_COLUMNS,
    METRICS_PATH,
    MODEL_DIR,
    NUMERIC_COLUMNS,
    RANDOM_SEED,
    REPORT_DIR,
    SYNTHETIC_DATA_PATH,
    TARGET_COLUMN,
)

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def make_preprocessor() -> ColumnTransformer:
    """Create a modeling preprocessor for numeric and categorical features."""
    return ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), NUMERIC_COLUMNS),
            ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLUMNS),
        ]
    )


def candidate_models() -> dict[str, object]:
    """Return configured model candidates."""
    return {
        "logistic_regression": LogisticRegression(max_iter=2000, class_weight="balanced", random_state=RANDOM_SEED),
        "random_forest": RandomForestClassifier(
            n_estimators=300,
            max_depth=12,
            class_weight="balanced_subsample",
            random_state=RANDOM_SEED,
            n_jobs=-1,
        ),
        "xgboost": XGBClassifier(
            n_estimators=350,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="binary:logistic",
            eval_metric="auc",
            random_state=RANDOM_SEED,
            n_jobs=-1,
        ),
    }


def load_training_sets(
    train_path: Path = CLEAN_TRAIN_PATH,
    test_path: Path = CLEAN_TEST_PATH,
    synthetic_path: Path = SYNTHETIC_DATA_PATH,
) -> dict[str, pd.DataFrame]:
    """Load real, synthetic, and hybrid train sets."""
    if not train_path.exists() or not test_path.exists():
        raise FileNotFoundError("Clean train/test data missing. Run src.preprocessing first.")
    real_train = pd.read_csv(train_path)
    test = pd.read_csv(test_path)
    if synthetic_path.exists():
        synthetic = pd.read_csv(synthetic_path)
    else:
        LOGGER.warning("Synthetic data not found at %s; using real minority bootstraps as a fallback.", synthetic_path)
        minority_class = real_train[TARGET_COLUMN].value_counts().idxmin()
        synthetic = real_train[real_train[TARGET_COLUMN] == minority_class].sample(
            n=max(100, real_train[TARGET_COLUMN].value_counts().max() - real_train[TARGET_COLUMN].value_counts().min()),
            replace=True,
            random_state=RANDOM_SEED,
        )
    hybrid = pd.concat([real_train, synthetic], ignore_index=True)
    return {"real": real_train, "synthetic": synthetic, "hybrid": hybrid, "test": test}


def evaluate_pipeline(pipeline: Pipeline, test_df: pd.DataFrame) -> dict[str, float]:
    """Evaluate a fitted pipeline on held-out real data."""
    x_test = test_df[FEATURE_COLUMNS]
    y_test = test_df[TARGET_COLUMN]
    pred = pipeline.predict(x_test)
    if hasattr(pipeline, "predict_proba"):
        proba = pipeline.predict_proba(x_test)[:, 1]
    else:
        proba = pred
    return {
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred, zero_division=0),
        "recall": recall_score(y_test, pred, zero_division=0),
        "f1": f1_score(y_test, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_test, proba),
    }


def train_all_models() -> pd.DataFrame:
    """Train all model/data-source combinations and save the best by ROC-AUC."""
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    datasets = load_training_sets()
    test_df = datasets.pop("test")
    records: list[dict[str, object]] = []
    best_score = -np.inf
    best_pipeline: Pipeline | None = None
    best_name = ""

    for source_name, train_df in datasets.items():
        x_train = train_df[FEATURE_COLUMNS]
        y_train = train_df[TARGET_COLUMN].astype(int)
        if y_train.nunique() < 2:
            LOGGER.warning("Skipping %s because it contains only one target class.", source_name)
            continue
        for model_name, model in candidate_models().items():
            pipeline = Pipeline([("preprocessor", make_preprocessor()), ("model", model)])
            pipeline.fit(x_train, y_train)
            metrics = evaluate_pipeline(pipeline, test_df)
            record = {"training_data": source_name, "model": model_name, **metrics}
            records.append(record)
            LOGGER.info("%s/%s metrics: %s", source_name, model_name, metrics)
            if metrics["roc_auc"] > best_score:
                best_score = metrics["roc_auc"]
                best_pipeline = pipeline
                best_name = f"{source_name}_{model_name}"

    if best_pipeline is None:
        raise RuntimeError("No model was trained.")
    joblib.dump(best_pipeline, BEST_MODEL_PATH)
    metrics_df = pd.DataFrame(records).sort_values("roc_auc", ascending=False)
    metrics_df.to_csv(METRICS_PATH, index=False)
    LOGGER.info("Saved best model %s with ROC-AUC %.4f to %s", best_name, best_score, BEST_MODEL_PATH)
    return metrics_df


if __name__ == "__main__":
    setup_logging()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    train_all_models()
