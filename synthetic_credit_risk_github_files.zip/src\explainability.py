"""Generate SHAP explainability artifacts for the best credit risk model."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import shap

from src.config import BEST_MODEL_PATH, CLEAN_TEST_PATH, FEATURE_COLUMNS, FIGURE_DIR, TARGET_COLUMN

LOGGER = logging.getLogger(__name__)


def setup_logging() -> None:
    """Configure readable command-line logging."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")


def transformed_feature_names(pipeline: object) -> list[str]:
    """Return feature names from the fitted preprocessing pipeline."""
    preprocessor = pipeline.named_steps["preprocessor"]
    return list(preprocessor.get_feature_names_out())


def compute_shap_values(model_path: Path = BEST_MODEL_PATH, test_path: Path = CLEAN_TEST_PATH, sample_size: int = 500):
    """Compute SHAP values against a sample of the test set."""
    if not model_path.exists() or not test_path.exists():
        raise FileNotFoundError("Best model and clean test data are required.")
    pipeline = joblib.load(model_path)
    test_df = pd.read_csv(test_path)
    sample = test_df.sample(n=min(sample_size, len(test_df)), random_state=42)
    transformed = pipeline.named_steps["preprocessor"].transform(sample[FEATURE_COLUMNS])
    feature_names = transformed_feature_names(pipeline)
    model = pipeline.named_steps["model"]

    try:
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(transformed)
    except Exception:
        background = transformed[: min(100, transformed.shape[0])]
        explainer = shap.KernelExplainer(model.predict_proba, background)
        shap_values = explainer.shap_values(transformed[: min(100, transformed.shape[0])])
        transformed = transformed[: min(100, transformed.shape[0])]

    if isinstance(shap_values, list):
        shap_values = shap_values[1]
    return pipeline, sample, transformed, feature_names, shap_values


def save_shap_plots() -> None:
    """Save global SHAP feature importance and summary plots."""
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    _, _, transformed, feature_names, shap_values = compute_shap_values()

    plt.figure()
    shap.summary_plot(shap_values, transformed, feature_names=feature_names, show=False)
    plt.tight_layout()
    plt.savefig(FIGURE_DIR / "shap_summary.png", dpi=160, bbox_inches="tight")
    plt.close()

    plt.figure()
    shap.summary_plot(shap_values, transformed, feature_names=feature_names, plot_type="bar", show=False)
    plt.tight_layout()
    plt.savefig(FIGURE_DIR / "shap_feature_importance.png", dpi=160, bbox_inches="tight")
    plt.close()
    LOGGER.info("Saved SHAP plots to %s", FIGURE_DIR)


def local_explanation(row: pd.DataFrame, model_path: Path = BEST_MODEL_PATH) -> dict[str, float]:
    """Return local top feature contributions for a single input row."""
    pipeline = joblib.load(model_path)
    transformed = pipeline.named_steps["preprocessor"].transform(row[FEATURE_COLUMNS])
    feature_names = transformed_feature_names(pipeline)
    model = pipeline.named_steps["model"]
    try:
        explainer = shap.TreeExplainer(model)
        values = explainer.shap_values(transformed)
        if isinstance(values, list):
            values = values[1]
        row_values = values[0]
    except Exception:
        return {}
    ranking = pd.Series(row_values, index=feature_names).sort_values(key=abs, ascending=False).head(10)
    return {str(k): float(v) for k, v in ranking.items()}


if __name__ == "__main__":
    setup_logging()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    save_shap_plots()
